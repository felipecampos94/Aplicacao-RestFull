/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.upf.ads.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;


@NamedNativeQueries({

    @NamedNativeQuery(name = "TbLivro.findByPartTitulo",
            query = "SELECT * FROM tb_livro AS livro WHERE livro.titulo ~* ?",
            resultClass = TbLivro.class)
})

@Entity
@Table(name = "tb_livro")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbLivro.findAll", query = "SELECT t FROM TbLivro t")
    , @NamedQuery(name = "TbLivro.findByIdLivro", query = "SELECT t FROM TbLivro t WHERE t.idLivro = :idLivro")
    , @NamedQuery(name = "TbLivro.findByTitulo", query = "SELECT t FROM TbLivro t WHERE t.titulo = :titulo")
    , @NamedQuery(name = "TbLivro.findByAutor", query = "SELECT t FROM TbLivro t WHERE t.autor = :autor")
    , @NamedQuery(name = "TbLivro.findByEditora", query = "SELECT t FROM TbLivro t WHERE t.editora = :editora")})
public class TbLivro implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_livro")
    private Integer idLivro;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "titulo")
    private String titulo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 250)
    @Column(name = "autor")
    private String autor;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "editora")
    private String editora;

    public TbLivro() {
    }

    public TbLivro(Integer idLivro) {
        this.idLivro = idLivro;
    }

    public TbLivro(Integer idLivro, String titulo, String autor, String editora) {
        this.idLivro = idLivro;
        this.titulo = titulo;
        this.autor = autor;
        this.editora = editora;
    }

    public Integer getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(Integer idLivro) {
        this.idLivro = idLivro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idLivro != null ? idLivro.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbLivro)) {
            return false;
        }
        TbLivro other = (TbLivro) object;
        if ((this.idLivro == null && other.idLivro != null) || (this.idLivro != null && !this.idLivro.equals(other.idLivro))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.upf.ads.entity.TbLivro[ idLivro=" + idLivro + " ]";
    }
    
}
