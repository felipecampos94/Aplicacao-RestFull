
package br.upf.ads.facade;

import br.upf.ads.entity.TbLivro;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


@Stateless
public class TbLivroFacade extends AbstractFacade<TbLivro> {

    @PersistenceContext(unitName = "RestLivrosWSPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TbLivroFacade() {
        super(TbLivro.class);
    }
    
    public List<TbLivro> findByPartTitulo(String partTitulo){
        List<TbLivro> lista = new ArrayList<>();
        try {
            Query query
                    = getEntityManager().createNamedQuery("TbLivro.findByPartTitulo");
            query.setParameter(1, partTitulo);
            lista = query.getResultList();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
        return lista;
    }
    
}
