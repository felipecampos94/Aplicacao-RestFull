package br.upf.ads.facade;

import br.upf.ads.entity.TbLivro;
import java.util.List;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Felipe
 */
public class LivroWSClientFacade {

    private final WebTarget webTarget;
    private final Client client;
    private static final String BASE_URI = "http://localhost:8080/RestLivrosWS/webresources";

    public LivroWSClientFacade() {
        client = javax.ws.rs.client.ClientBuilder.newClient();
        webTarget = client.target(BASE_URI).path("livros");
    }

    public List<TbLivro> findAll() throws ClientErrorException {
        List<TbLivro> list;
        WebTarget resource = webTarget;
        resource = resource.path("listAll");
        list = resource.request(
                javax.ws.rs.core.MediaType.APPLICATION_JSON)
                .get(new GenericType<List<TbLivro>>() {
                });
        return list;
    }

    public TbLivro findById(String id) throws ClientErrorException {
        TbLivro tbLivro;
        WebTarget resource = webTarget;
        resource = resource.path(java.text.MessageFormat
                .format("findByID/{0}", new Object[]{id}));
        tbLivro = resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON)
                .get(new GenericType<TbLivro>() {
                });

        return tbLivro;
    }

    public List<TbLivro> findByPartTitulo(String partTitulo) throws ClientErrorException {
        List<TbLivro> list;
        WebTarget resource = webTarget;
        resource = resource.path(java.text.MessageFormat
                .format("findByPartTitulo/{0}", new Object[]{partTitulo}));

        list = resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON)
                .get(new GenericType<List<TbLivro>>() {
                });

        return list;
    }

    public void create(TbLivro entity) throws ClientErrorException {
        webTarget.path("add").request().post(Entity.entity(entity, MediaType.APPLICATION_JSON));

    }

    public void edit(TbLivro entity) throws ClientErrorException {
        webTarget.path("edit").request().put(Entity.entity(entity, MediaType.APPLICATION_JSON));
    }
    
    public void remove(String id) throws ClientErrorException{
        webTarget.path(java.text.MessageFormat.format("delete/{0}", new Object[]{id})).request().delete();
    }
}
