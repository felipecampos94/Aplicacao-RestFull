
package br.upf.ads.entity;

import java.io.Serializable;

public class TbLivro implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer idLivro;
    private String titulo;
    private String autor;
    private String editora;

    public TbLivro() {
    }

    public TbLivro(Integer idLivro) {
        this.idLivro = idLivro;
    }

    public TbLivro(Integer idLivro, String titulo, String autor, String editora) {
        this.idLivro = idLivro;
        this.titulo = titulo;
        this.autor = autor;
        this.editora = editora;
    }

    public Integer getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(Integer idLivro) {
        this.idLivro = idLivro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idLivro != null ? idLivro.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbLivro)) {
            return false;
        }
        TbLivro other = (TbLivro) object;
        if ((this.idLivro == null && other.idLivro != null) || (this.idLivro != null && !this.idLivro.equals(other.idLivro))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return titulo;
    }

}
