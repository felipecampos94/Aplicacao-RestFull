package br.upf.ads.teste;

import br.upf.ads.entity.TbLivro;
import br.upf.ads.facade.LivroWSClientFacade;
import java.util.List;

public class LivroWSClientFacadeTeste {

    private final static LivroWSClientFacade NRC = new LivroWSClientFacade();

    private static void findAllTest() {
        List<TbLivro> list = NRC.findAll();
        if (!list.isEmpty()) {
            System.out.println("Lista de registros localizados...");
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i).getIdLivro() + " - " + list.get(i).getTitulo());
            }
            System.out.println("-------------------------------------------------");
        } else {
            System.out.println("Nenhum registro localizado...");
        }
    }

    private static TbLivro findByIdTest(String id) {
        TbLivro livro = NRC.findById(id);
        if (livro != null) {
            System.out.println("Registro localizado com sucesso");
            System.out.println(livro.getIdLivro() + "-" + livro.getTitulo());
        } else {
            System.out.println("Não foi localizado nenhum registro com o id " + id);
        }

        System.out.println("------------------------------------------");
        return livro;
    }

    private static void findByPartTituloTest(String partTitulo) {
        List<TbLivro> list = NRC.findByPartTitulo(partTitulo);
        if (!list.isEmpty()) {
            System.out.println("Registros localizados...");
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i).getIdLivro() + " - " + list.get(i).getTitulo());
            }
            System.out.println("---------------------------------------");

        } else {
            System.out.println("Nenhum registro localizado.");
        }
    }

    private static void createTest() {
        TbLivro entity = new TbLivro();
        entity.setTitulo("Novo Livro");
        entity.setAutor("Novo Autor");
        entity.setEditora("Nova Editora");
        NRC.create(entity);
        System.out.println("Registro criado com sucesso");
    }

    private static void editTest() {
        String id = "11";

        if (findByIdTest(id) != null) {
            TbLivro entity = NRC.findById(id);
            entity.setTitulo("Aprenda PHP");
            entity.setAutor("Cara da Net");
            entity.setEditora("New Editora");
            NRC.edit(entity);
            System.out.println("Registro alterado com sucesso!");
        }
    }

    private static void removeTest(String id) {
        if (findByIdTest(id) != null) {
            NRC.remove(id);
            System.out.println("ID Localizado: " + id);
            System.out.println("Registro removido com sucesso!");
        }
    }

    public static void main(String[] args) {
        findAllTest();
        findByIdTest("4");
        findByPartTituloTest("sitio");
//        createTest();
//        editTest();
//        removeTest("11");

    }

}
